package Model;

import org.eclipse.swt.graphics.Color;

public class Section {
	private String sectionName;
	private String startAddress;
	private String usedSize;
	private int color;
	
	public Section(String sectionName, String startAddress, String usedSize, int color) {
		super();
		this.sectionName = sectionName;
		this.startAddress = startAddress;
		this.usedSize = usedSize;
		this.color = color;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public String getStartAddress() {
		return startAddress;
	}

	public void setStartAddress(String startAddress) {
		this.startAddress = startAddress;
	}

	public String getUsedSize() {
		return usedSize;
	}

	public void setUsedSize(String usedSize) {
		this.usedSize = usedSize;
	}

	public int getColor() {
		return color;
	}

	public void setColor(int color) {
		this.color = color;
	}
	
	

}
