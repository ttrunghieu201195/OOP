package SWT;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;

public class CompositeChild extends Composite {

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public CompositeChild(Composite parent, Section section, int style) {
		super(parent, style);
		GridLayout grid = new GridLayout();
		grid.numColumns = 2;
		this.setLayout(grid);
		this.setLayoutData(new GridData(SWT.FILL, SWT.DEFAULT, true, true));
		
		Label address = new Label(this, SWT.BORDER);
		address.setText(section.getStartAddress());
		address.pack();
		address.setLayoutData(new GridData(SWT.RIGHT, SWT.TOP, true, true));
		
		Composite sectionRight = new Composite(this, SWT.BORDER);		
		sectionRight.setLayout(new GridLayout(1, false));
		sectionRight.setLayoutData(new GridData(SWT.FILL, SWT.DEFAULT, true, true));
		sectionRight.setBackground(SWTResourceManager.getColor(section.getColor()));
		Label sectionName = new Label(sectionRight, SWT.BORDER);
		sectionName.setText(section.getSectionName());
		sectionName.setLayoutData(new GridData(SWT.LEFT, SWT.TOP, true, true));
		Label usedSize = new Label(sectionRight, SWT.BORDER);
		usedSize.setText(section.getUsedSize());
		usedSize.setLayoutData(new GridData(SWT.RIGHT, SWT.BOTTOM, true, true));
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
