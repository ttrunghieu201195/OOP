package SWT;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;

public class DefinedSection extends Composite {

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public DefinedSection(Composite parent, Section section, int style) {
		super(parent, style);
		this.setLayout(new GridLayout(1, false));
//		Composite sectionComposite = new Composite(this, SWT.BORDER);
//		GridLayout grid = new GridLayout();
//		grid.numColumns = 1;
//		sectionComposite.setLayout(grid);
		
		CompositeChild child = new CompositeChild(this, section, SWT.BORDER);
//		CompositeChild child1 = new CompositeChild(this, section, SWT.BORDER);
		CompositeChild child2 = new CompositeChild(this, section, SWT.BORDER);
		
//		Label sectionName = new Label(sectionRight, SWT.NONE);
//		sectionName.setText(section.getSectionName());
//		sectionName.setBackground(SWTResourceManager.getColor(section.getColor()));
//		
//		Label usedSize = new Label(sectionComposite, SWT.NONE);
//		usedSize.setText(section.getUsedSize());
//		usedSize.setBackground(SWTResourceManager.getColor(section.getColor()));

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
