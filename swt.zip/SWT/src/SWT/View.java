package SWT;

import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import org.eclipse.swt.SWT;

public class View {

	protected Shell shell;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			View window = new View();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 300);
		shell.setText("SWT Application");
		shell.setLayout(new FillLayout());
		
		Composite composite = new Composite(shell, SWT.BORDER);
		
		GridLayout grid = new GridLayout(2, true);
//		//grid.numColumns = 2;
		composite.setLayout(grid);
		Section section = new Section("[D] stack", "000000", "0/1024B", SWT.COLOR_GRAY);
		DefinedSection definedSection = new DefinedSection(composite, section, SWT.BORDER);
		definedSection.setLayoutData(new GridData(SWT.FILL, SWT.DEFAULT, true, true));
		Section section2 = new Section("[D] stack", "000999", "0/1024B", SWT.COLOR_RED);
		DefinedSection definedSection1 = new DefinedSection(composite, section2, SWT.BORDER);
		definedSection1.setLayoutData(new GridData(SWT.FILL, SWT.DEFAULT, true, true));
	}

}
